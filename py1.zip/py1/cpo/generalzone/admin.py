from django.contrib import admin
from.models import Enquiry,costomerInfo,loginInfo
# Register your models here.
admin.site.register(Enquiry)
admin.site.register(costomerInfo)
admin.site.register(loginInfo)