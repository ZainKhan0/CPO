from django.apps import AppConfig


class GeneralzoneConfig(AppConfig):
    name = 'generalzone'
