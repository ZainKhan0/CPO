from django.conf.urls import url
from . import views
urlpatterns=[
    url(r'userhome',views.userhome,name='userhome'),
    url(r'discussion',views.discussion,name='discussion'),
    url(r'searchsolution',views.searchsolution,name='searchsolution'),
    url(r'complainlog',views.complainlog,name='complainlog'),
    url(r'changepassword',views.changepassword,name='changepassword'),
    url(r'logout',views.logout,name='logout'),
    url(r'savecomplain',views.savecomplain,name='savecomplain'),
    url(r'changepwd',views.changepwd,name='changepwd'),
    url(r'viewanswer',views.viewanswer,name='viewanswer'),
    url(r'postquestion',views.postquestion,name='postquestion'),
    url(r'postanswer',views.postanswer,name='postanswer'),
    url(r'search',views.search,name='search'),

]