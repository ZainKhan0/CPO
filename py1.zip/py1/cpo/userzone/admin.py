from django.contrib import admin
from . models import complain
# Register your models here.
admin.site.register(complain)