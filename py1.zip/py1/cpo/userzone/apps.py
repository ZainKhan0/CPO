from django.apps import AppConfig


class UserzoneConfig(AppConfig):
    name = 'userzone'
