from django.shortcuts import render,redirect,reverse
from generalzone.models import costomerInfo
from adminzone.models import knowledgebase
import datetime
from .models import complain
from generalzone.models import loginInfo
# Create your views here.
def userhome(request):
    if request.session['userid']:
        return render(request,'userhome.html')
    else:
        return render(request,'login.html')
def discussion(request):
    if request.session['userid']:
        return render(request,'discussion.html')
    else:
        return render(request,'login.html')
def complainlog(request):
    if request.session['userid']:
        return render(request,'complainlog.html')
    else:
        return render(request,'login.html')
def searchsolution(request):
    if request.session['userid']:
        return render(request,'searchsolution.html')
    else:
        return render(request,'login.html')
def changepassword(request):
    if request.session['userid']:
        return render(request,'changepassword.html')
    else:
        return render(request,'login.html')
def logout(request):
    if request.session['userid']:
        return render(request,'logout.html')
    else:
        return render(request, 'login.html')
def savecomplain(request):
    if request.session['userid']:
        emailaddress=request.session.get('userid')
        customer=costomerInfo.objects.get(emailaddress=emailaddress)
        name=customer.name
        gender=customer.gender
        address=customer.address
        contactno=customer.contactno
        subject=request.POST['subject']
        complaintext=request.POST['complaintext']
        complaindate=datetime.datetime.now().strftime('%Y/%m/%d')
        comp=complain(name=name,gender=gender,address=address,contactno=contactno,emailaddress=emailaddress,subject=subject,complaintext=complaintext)
        comp.save()
        return redirect('userzone:userhome')
    else:
        return render(request,'login.html')
def changepwd(request):
    if request.session['userid']:
        userid=request.session['userid']
        oldpassword=request.POST['oldpassword']
        newpassword=request.POST['newpassword']
        confirmpassword=request.POST['confirmpassword']
        if newpassword!=confirmpassword:
            return redirect('userzone:changepassword')
        else:
            user=loginInfo.objects.get(userid=userid,password=oldpassword)
            if user is not None:
                li=loginInfo(password=newpassword,userid=userid)
                li.save()
                return render(request,'login.html')
            else:
                return redirect('userzone:changepassword')
    else:
        return render(request,'login.html')
def viewanswer(request,qid):
    if request.session['userid']:
        ans=answer.objects.get(qid=qid)
        return render(request,'viewanswer.html',{'ans':ans})
    else:
        return render(request,'login.html')
def postquestion(request):
    if request.session['userid']:
        emailaddress=request.session.get('userid')
        costomer=costomerInfo.objects.get(emailaddress=emailaddress)
        askedby=costomer.name
        questiontext=request.POST['questiontext']
        posteddate=datetime.datetime.now().strftime('%Y/%m/%d')
        q=question(questiontext=questiontext,askedby=askedby,posteddate=posteddate)
        q.save()
        return redirect('userzone:discussion')
    else:
        return render(request,'login.html')
def answer(request,qid):
    if request.session['userid']:
        return render(request,'answer.html',{'qid':qid})
    else:
        return render(request,'login.html')
def postanswer (request,uid):
    if request.session['userid']:
        emailaddress = request.session.get('userid')
        costomer = costomerInfo.objects.get(emailaddress=emailaddress)
        answeredby = costomer.name
        qid = request.POST['qid']
        answertext = request.POST['answertext']
        answereddate = datetime.datetime.now().strftime('%Y/%m/%d')
        a=answer(answertext=answertext,answeredby=answeredby,posteddate=posteddate)
        q.save()
        return redirect('userzone:discussion')
    else:
        return render(request, 'login.html')
def search(request):
    if request.session['userid']:
        searchtext=request.POST['searchtext']
        kw=knowledgebase.objects.filter(Q(problemid=searchtext) | Q(problemtext=searchtext))
        return render(request,'searchsolution.html',{'kw':kw})
    else:
        return render(request,'login.html')