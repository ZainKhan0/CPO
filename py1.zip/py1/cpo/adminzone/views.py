from django.shortcuts import render,redirect
import datetime
from generalzone.models import Enquiry,costomerInfo,loginInfo
from userzone.models import complain
from . models import knowledgebase,notification
# Create your views here.
def adminhome(request):
    if request.session['adminid']:
        noti=notification.objects.all()
        return render(request,'adminhome.html',{'noti':noti})
    else:
        return render(request,'login.html')
def complains(request):
    if request.session['adminid']:
        comp=complain.objects.all()
        return render(request,'complains.html',{'comp':comp})
    else:
        return render(request,'login.html')
def enquires(request):
    if request.session['adminid']:
        enq=Enquiry.objects.all()
        return render(request,'enquires.html',{'enq':enq})
    else:
        return render(request,'login.html')
def customerinfo(request):
    if request.session['adminid']:
        cust=costomerInfo.objects.all()
        return render(request,'customerinfo.html',{'cust':cust})
    else:
        return render(request,'login.html')
def knowledgebase(request):
    if request.session['adminid']:
        return render(request,'knowledgebase.html')
    else:
        return render(request,'login.html')
def logout(request):
    del request.session['adminid']
    return render(request,'login.html')
def addnotification(request):
    if request.session['adminid']:
        notificationtext=request.POST['notificationtext']
        posteddate=datetime.datetime.now().strftime('%Y/%m/%d')
        n=notification(notificationtext=notificationtext,posteddate=posteddate)
        return redirect('adminzone:adminhome')
    else:
        return render(request,'login.html')
def deletenotification(request,id):
    if request.session['adminid']:
        n=notification.objects.get(id=id)
        n.delete()
        return redirect('adminzone:adminhome')
    else:
        return render(request,'login.html')
def deleteenquires(request):
    if request.session['adminid']:
        e=enquiiry.objects.get(id=id)
        e.delete()
        return redirect('adminzone:enquires')
    else:
        return render(request,'login.html')
def deletecomplains(request,id):
    if request.session['adminid']:
        c=complains.objects.all()
        c.delete()
        return redirect('adminzone:complains')
    else:
        return render(request,'login.html')
def deletecostomerinfo(request,emailaddress):
    if request.session['adminid']:
        c=costomerInfo.objects.get(emailaddress=emailaddress)
        l=loginInfo.objects.get(userid=emailaddress)
        c.delete()
        l.delete()
        return redirect('adminzone:customerinfo')
    else:
        return render(request,'login.html')
def saveknowledgebase(request):
    if request.session['adminid']:
        problemid=request.POST['problemid']
        problemtext=request.POST['problemtext']
        solutiontext=request.POST['solutiontext']
        posteddate=datetime.datetime.now().strftime('%Y/%m/%d')
        kw=knowledgebase(problemid=problemid,problemtext=problemtext,solutiontext=solutiontext,posteddate=posteddate)
        kw.save()
        return redirect('adminzone:knowledgebase')
    else:
      return render(request,'login.html')
