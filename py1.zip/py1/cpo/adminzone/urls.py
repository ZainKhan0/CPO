from django.conf.urls import url
from . import views
urlpatterns=[
    url(r'^adminhome',views.adminhome,name='adminhome'),
    url(r'^enquires',views.enquires,name='enquires'),
    url(r'^customerinfo',views.customerinfo,name='customerinfo'),
    url(r'^complains',views.complains,name='complains'),
    url(r'^knowledgebase',views.knowledgebase,name='knowledgebase'),
    url(r'^logout',views.logout,name='logout'),
    url(r'^addnotification',views.addnotification,name='addnotification'),
    url(r'^deletenotification/(?P<id>\d+)$',views.deletenotification,name='deletenotification'),
    url(r'^deleteenquires/(?P<id>\d+)$',views.deleteenquires,name='deleteenquires'),
    url(r'^deletecomplains/(?P<id>\d+)$',views.deletecomplains,name='deletecomplains'),
    url(r'^deletecostomerinfo/(?P<emailaddress>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/$',views.deletecostomerinfo,name='deletecostomerinfo'),
    url(r'^saveknowledgebase',views.saveknowledgebase,name='saveknowledgebase'),
    ]