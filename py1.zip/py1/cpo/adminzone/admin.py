from django.contrib import admin
from . models import notification,knowledgebase
# Register your models here.
admin.site.register(notification)
admin.site.register(knowledgebase)